//passo 1 - pegar botões de filtro e colocar no js
const botaofiltrar = document.querySelector('.Btn-filtrar')
console.log(botaofiltrar)

//passo 2 - aplicar filtro ao ouvir o click do botão
botaofiltrar.addEventListener('click', function () {
    console.log('clicou no botão filtrar')
    //passo 3 - pegar o valor do preço e usar input
    const categoriaSelecionada = document.querySelector('#categoria').value;
    const precoMaximoSelecionado = document.querySelector('#preco').value;
    // parte 4 - pra cada carta esconda ou mostre a carta selecionada
    const cartas = document.querySelectorAll('.carta');

    cartas.forEach(function (carta) {
    const categoriaCarta = carta.dataset.categoria;
    const precoCarta = carta.dataset.preco;
    
    let mostrarCarta = true;

    console.log("Categoria selecionada:", categoriaSelecionada);

  const temFiltroDeCategoria = categoriaSelecionada !== '';

  const cartaNaoBateComFiltroDeCategoria = categoriaSelecionada.toLowerCase() !== categoriaCarta.toLowerCase();

    if (temFiltroDeCategoria && cartaNaoBateComFiltroDeCategoria){
        mostrarCarta = false;
    
    }

    const temFiltroDePreco = precoMaximoSelecionado !== '';
    const cartaNaoBateComFiltroDePrecoMaximo = parseFloat(precoCarta) > parseFloat(precoMaximoSelecionado);
    if(temFiltroDePreco && cartaNaoBateComFiltroDePrecoMaximo){
        mostrarCarta = false;
    }

if(precoMaximoSelecionado !== '' && parseFloat(precoCarta) > parseFloat(precoMaximoSelecionado)){
    mostrarCarta = false;
}

    if (mostrarCarta) {
        carta.classList.add('mostrar')
       carta.classList.remove('esconder');
    } else{
        carta.classList.remove('mostrar');
        carta.classList.add('esconder');
    }

    });
});





function updatemenu() {
  if (document.getElementById('responsive-menu').checked == true) {
    document.getElementById('menu').style.borderBottomRightRadius = '0';
    document.getElementById('menu').style.borderBottomLeftRadius = '0';
  }else{
    document.getElementById('menu').style.borderRadius = '10px';
  }
}
